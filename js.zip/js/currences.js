var currencies = [
	{
		txt:"EUR",
		value:"€",
	},
	{
		txt:"USD",
		value:"$",
	},
	{
		txt:"POUND",
		value:"£",
	},
	{
		txt:"CHF Suisse",
		value:"CHF",
	}
]